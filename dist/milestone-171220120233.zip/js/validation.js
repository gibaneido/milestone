/**
* @author Paulo Martins <phmartins6@gmail.com>
*/

var Validation = {
	
	email: function() {
		
	}
	
};